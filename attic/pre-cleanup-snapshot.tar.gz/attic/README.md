# Archived project material

This directory contains the pre-cleanup research notebooks, reports, implementation branches, run evidence, and historical documentation retained for provenance. It is not part of the EQG product API and is intentionally not linked from the product README. Source artifacts are retained rather than deleted; for release/distribution, review third-party terms and confidential material before including this archive.
